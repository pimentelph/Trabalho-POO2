﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Lógica interna para TelaPrincipal.xaml
    /// </summary>
    public partial class TelaPrincipal : Window
    {
        public TelaPrincipal()
        {
            InitializeComponent();
        }

        private void IniciarJogo(object sender, RoutedEventArgs e)
        {
            MainWindow novaTelaJogo = new MainWindow();

            novaTelaJogo.Show();

            this.Close();
        }

        private void FecharJogo(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
